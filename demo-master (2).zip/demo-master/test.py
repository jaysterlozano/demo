print(8%10)

x = 'abc_%(key)s_'
x %= {'key':'value'}
print(x) 

x = 'Sir %(Name)s '
x %= {'Name':'Lancelot'}
print(x) 
